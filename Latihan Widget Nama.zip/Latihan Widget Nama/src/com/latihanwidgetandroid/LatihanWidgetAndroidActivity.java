package com.latihanwidgetandroid;


import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class LatihanWidgetAndroidActivity extends Activity implements OnClickListener{
    /** Called when the activity is first created. */
	
	Button btn_ok, btn_clear, btn_exit;
	EditText Edit_Text1, Edit_Text2;
	TextView tv_depan,tv_belakang, tv_hasil;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    
        btn_ok =(Button) findViewById(R.id.btnok);
        btn_clear =(Button) findViewById(R.id.btnclear);
        btn_exit =(Button) findViewById(R.id.btnclose);
        Edit_Text1 =(EditText) findViewById(R.id.editText1);
        Edit_Text2 =(EditText) findViewById(R.id.editText2);
        tv_depan =(TextView) findViewById(R.id.tvdepan);
        tv_belakang =(TextView) findViewById(R.id.tvbelakang);
        tv_hasil =(TextView) findViewById(R.id.tvhasil);
        
        btn_ok.setOnClickListener(this);
        btn_clear.setOnClickListener(this);
        btn_exit.setOnClickListener(this);
    }
    public void onClick(View v) {
    	if (v == btn_ok){
			tv_depan.setText("Nama Depan Anda Adalah = " + Edit_Text1.getText());
			tv_belakang.setText("Nama belakang Anda Adalah = " + Edit_Text2.getText());
    		tv_hasil.setText("Nama panjang Anda Adalah = " + Edit_Text1.getText() +" "  + Edit_Text2.getText());
    }else if (v == btn_clear){
    			Edit_Text1.setText("");
    			Edit_Text2.setText("");
    			tv_depan.setText("Nama Depan Anda Adalah = ");
    			tv_belakang.setText("Nama Belakang Anda Adalah = ");
    			tv_hasil.setText("Nama Panjang Anda Adalah = ");
    }else {
    	finish();
    }
    	
    }
    
}