package com.radio;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.RadioGroup;
import android.widget.TextView;

public class RadioButtonAppActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
    }
    public void klickOk(View v){
    	RadioGroup rg_JK = (RadioGroup) findViewById(R.id.rgJenisKelamin);
    	TextView tv_Hasil = (TextView) findViewById(R.id.tvHasil);
    	
    	int id_rb = rg_JK.getCheckedRadioButtonId();
    	
    	if (id_rb ==R.id.rbLaki){
    		tv_Hasil.setText("Hasil : Laki-Laki");
    	} else {
    		tv_Hasil.setText("Hasil : Perempuan");
    	}
    	
    }
}