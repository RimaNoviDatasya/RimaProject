package com.intent;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

public class IntentActivity extends Activity implements OnClickListener{
	
	
	EditText edt_Nama;
	Button btn_Next;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        edt_Nama = (EditText) findViewById(R.id.edtNama);
        btn_Next = (Button)findViewById(R.id.btnNext);
        
        btn_Next.setOnClickListener(this);
    }
    @Override
    public void onClick(View arg0){
    	Intent intent = new Intent(this, page_2.class);
    	intent.putExtra("Nama", edt_Nama.getText().toString());
    	startActivity(intent);
    }
}