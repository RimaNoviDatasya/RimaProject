package com.db;


import com.nilaidb.R;

import android.app.Activity;
import android.app.AlertDialog;
import android.os.Bundle;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.AdapterView.OnItemClickListener;


public class UasActivity extends Activity {
    /** Called when the activity is first created. */
	
	 
    String[] daftar;
    ListView lvData;
    Cursor cursor;
    DataHelper dbCenter;
    public static UasActivity ma;
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
 
        ma = this;
        dbCenter = new DataHelper(this);
        RefreshList();
 }
    
    public void RefreshList(){
    	SQLiteDatabase db = dbCenter.getReadableDatabase();
    	cursor = db.rawQuery("SELECT * FROM nilai", null);
    	daftar = new String[cursor.getCount()];
    	cursor.moveToFirst();
    	
    	for(int i = 0 ; i < cursor.getCount(); i++){
    		cursor.moveToPosition(i);
    		daftar[i] = cursor.getString(1).toString();
    	}
    			lvData = (ListView) findViewById(R.id.listView1);
    			lvData.setAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,daftar));
    			
    			lvData.setSelected(true);
    			lvData.setOnItemClickListener(new OnItemClickListener() {
    				public void onItemClick(AdapterView<?> arg0, View arg1, int arg2, long arg3){
    					final String selection = daftar[arg2];
    					final CharSequence[] dialogitem = {"ubah data","hapus data"};
    					
    					AlertDialog.Builder builder = new AlertDialog.Builder(UasActivity.this);
    					builder.setTitle("pilihan");
    					builder.setItems(dialogitem, new DialogInterface.OnClickListener() {
							
							public void onClick(DialogInterface dialog, int item) {
								// TODO Auto-generated method stub
								switch (item){
								case 0:
									
									
								case 1:
									Intent inten = new Intent(getApplicationContext(),ubah_data.class);
									inten.putExtra("nama", selection);
									startActivity(inten);
									break;
									
								case 2:
									SQLiteDatabase db = dbCenter.getReadableDatabase();
									db.execSQL("DElETE FROM nilai WHERE nama = '" + selection + "'");
									RefreshList();
									break;
								
					
							}
						}
						});
    					builder.create().show();
    				}
    					
    				});
    			}
    }
