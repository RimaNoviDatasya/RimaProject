package com.db;

import com.nilaidb.R;
import android.app.Activity;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class ubah_data extends Activity{

	protected Cursor cursor;
	DataHelper dbHelper;
	Button btnSave, btnCancel;
	EditText edtnirm, edtnama, edtmatakuliah, edtnilai;
@Override
protected void onCreate(Bundle saveInstanceState){
	super.onCreate(saveInstanceState);
	setContentView(R.layout.ubah_data);
	
	dbHelper = new DataHelper(this);
	
	edtnirm = (EditText) findViewById(R.id.editText1);
	edtnama = (EditText) findViewById(R.id.editText2);
	edtmatakuliah = (EditText) findViewById(R.id.editText3);
	edtnilai = (EditText) findViewById(R.id.editText4);
	
	
	SQLiteDatabase db = dbHelper.getReadableDatabase();
	cursor = db.rawQuery("SELECT * FROM nilai WHERE nama = '"
			+ getIntent().getStringExtra("matakuliah")+"'", null);
	cursor.moveToFirst();
	
	if (cursor.getCount()>0){
		cursor.moveToPosition(0);
		edtnirm.setText(cursor.getString(0).toString());
		edtnama.setText(cursor.getString(1).toString());
		edtmatakuliah.setText(cursor.getString(2).toString());
		edtnilai.setText(cursor.getString(3).toString());
		
	}
	btnSave = (Button) findViewById(R.id.button1);
	btnCancel = (Button) findViewById(R.id.button2);
	
	btnSave.setOnClickListener(new View.OnClickListener() {
		
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			SQLiteDatabase db = dbHelper.getWritableDatabase();
			db.execSQL("Update perpustakaan set nama = '"
					+ edtnama.getText().toString()+"', matakuliah='"
					+ edtmatakuliah.getText().toString()+"', nilai='"
					+ edtnilai.getText().toString()+ "'WHERE nirm = '"
					+ edtnirm.getText().toString()+"'");
			Toast.makeText(getApplicationContext(), "Berhasil", Toast.LENGTH_LONG).show();
			UasActivity.ma.RefreshList();
			finish();
		}
	});
	

	btnCancel.setOnClickListener(new View.OnClickListener() {
		
		public void onClick(View arg0) {
			// TODO Auto-generated method stub
			finish();
		}
	});
	
} 

}
